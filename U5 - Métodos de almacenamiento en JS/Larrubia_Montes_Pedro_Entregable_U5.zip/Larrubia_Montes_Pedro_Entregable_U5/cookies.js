var muestra = document.getElementById("muestra");
var cabecera = document.getElementById("cabecera");
var parrafo = document.getElementById("parrafo");

let color_fondo = document.getElementById("color_fondo");

let color_cabecera = document.getElementById("color_cabecera");
let fuente_cabecera = document.getElementById("fuente_cabecera");
let aliniacion_cabecera = document.getElementById("aliniacion_cabecera");
let tamano_cabecera = document.getElementById("tamano_cabecera");

let color_parrafo = document.getElementById("color_parrafo");
let fuente_parrafo = document.getElementById("fuente_parrafo");
let aliniacion_parrafo = document.getElementById("aliniacion_parrafo");
let tamano_parrafo = document.getElementById("tamano_parrafo");

// ------------------------BOTONES-----------------------------

let aplicar = document.getElementById("aplicar");
let guardar_cookies = document.getElementById("Guardar_Cookies");
let cargar_cookies = document.getElementById("Cargar_Cookies");
let sesion = document.getElementById("sesion");
let guardar_predeterminado = document.getElementById("Guardar_predeterminado");
let cargar_predeterminado = document.getElementById("Cargar_predeterminado");


window.onload = inicio();
function inicio() {
  aplicar.addEventListener("click", aplicarFormulario);
  guardar_cookies.addEventListener("click", guardarCookie);
  cargar_cookies.addEventListener("click", cargarCookie);
  sesion.addEventListener("click", guardarSession);
  guardar_predeterminado.addEventListener("click", guardarLocal);
  cargar_predeterminado.addEventListener("click",)
}

function aplicarFormulario() {
  cambiarFondo();
  cambiarColorCabecera();
  cambiarEstiloCabecera();
  cambiarAlingCabecera();
  cambiarTamCabecera();
  cambiarColorParrafo();
  cambiarEstiloParrafo();
  cambiarAlingParrafo();
  cambiarTamParrafo();
}




function cambiarFondo() {
  muestra.style.backgroundColor = color_fondo.value;
  return muestra.style.backgroundColor;
}



function cambiarColorCabecera() {
  cabecera.style.color = color_cabecera.value;
  return cabecera.style.color;
}

function cambiarEstiloCabecera() {
  cabecera.style.fontFamily = fuente_cabecera.value;
  return cabecera.style.fontFamily;
}

function cambiarAlingCabecera() {
  cabecera.style.textAlign = aliniacion_cabecera.value;
  return cabecera.style.textAlign;
}

function cambiarTamCabecera() {
  cabecera.style.fontSize = tamano_cabecera.value;
  return cabecera.style.fontSize;
}

function cambiarColorParrafo() {
  parrafo.style.color = color_parrafo.value;
  return parrafo.style.color;
}

function cambiarEstiloParrafo() {
  parrafo.fontFamily = fuente_parrafo.value;
  return parrafo.fontFamily;
}

function cambiarAlingParrafo() {
  parrafo.style.textAlign = aliniacion_parrafo.value;
  return parrafo.style.textAlign;
}

function cambiarTamParrafo() {
  parrafo.style.fontSize = tamano_parrafo.value;
  return parrafo.style.fontSize;
}

function guardarCookie() {
  let expiracion = prompt("Cuantos dias quieres que dure la cookie?");
  set_cookie(expiracion, cambiarFondo(), cambiarColorCabecera(), cambiarEstiloCabecera(), cambiarAlingCabecera(), cambiarTamCabecera(), cambiarColorParrafo(), cambiarEstiloParrafo(), cambiarAlingParrafo(), cambiarTamParrafo());
}

function set_cookie(expiracion, colorFondo, colorCabecera, estiloCabecera, alineacionCabecera, tamanoCabecera, colorParrafo, estiloParrafo, alineacionParrafo, tamanoParrafo) {
  let d = new Date();
  d.setTime(d.getTime() + expiracion * 24 * 60 * 60 * 1000);
  expiracion = "expires=" + d.toUTCString();
  document.cookie = "Color Fondo= " + colorFondo + expiracion + ";path=/";
  document.cookie = "Color Cabecera= " + colorCabecera + ";" + expiracion + ";path=/";
  document.cookie = "Fuente Cabecera= " + estiloCabecera + ";" + expiracion + ";path=/";
  document.cookie = "Aliniación Cabecera= " + alineacionCabecera + ";" + expiracion + ";path=/";
  document.cookie = "Tamaño Cabecera= " + tamanoCabecera + ";" + expiracion + ";path=/";
  document.cookie = "Color Parrafo= " + colorParrafo + ";" + expiracion + ";path=/";
  document.cookie = "Fuente Parrafo= " + estiloParrafo + ";" + expiracion + ";path=/";
  document.cookie = "Aliniación Parrafo= " + alineacionParrafo + ";" + expiracion + ";path=/";
  document.cookie = "Tamaño Parrafo= " + tamanoParrafo + ";" + expiracion + ";path=/";
}

function get_cookie(nombre) {
  let nom = nombre + "=";
  let array = document.cookie.split(";");
  for (let i = 0; i < array.length; i++) {
    let c = array[i];
    console.log(c);
    while (c.charAt(0) == " ") {
      c = c.substring(1);
    }
    if (c.indexOf(nom) == 0) {
      return c.substring(nom.length);
    }
  }
  return "";
}






function cargarCookie() {
  muestra.style.backgroundColor = get_cookie("Color Fondo");
  cabecera.style.color = get_cookie("Color Cabecera");
  cabecera.style.fontFamily = get_cookie("Fuente Cabecera");
  cabecera.style.textAlign = get_cookie("Aliniación Cabecera");
  cabecera.style.fontSize = get_cookie("Tamaño Cabecera");
  parrafo.style.color = get_cookie("Color Parrafo");
  parrafo.style.fontFamily = get_cookie("Fuente Parrafo");
  parrafo.style.textAlign = get_cookie("Aliniación Parrafo");
  parrafo.style.color = get_cookie("Tamaño Parrafo");

  color_fondo.value = get_cookie("Color Fondo");
  color_cabecera.value = get_cookie("Color Cabecera");
  fuente_cabecera.value = get_cookie("Fuente Cabecera");
  aliniacion_cabecera.value = get_cookie("Aliniación Cabecera");
  tamano_cabecera.value = get_cookie("Tamaño Cabecera");
  color_parrafo.value = get_cookie("Color Parrafo");
  fuente_parrafo.value = get_cookie("Fuente Parrafo");
  aliniacion_parrafo.value = get_cookie("Aliniación Parrafo");
  tamano_parrafo.value = get_cookie("Tamaño Parrafo");
}



function guardarSession() {
  let color = document.getElementById("color_fondo");
  let colorC = document.getElementById("color_cabecera");
  let fuenteC = document.getElementById("fuente_cabecera");
  let alingC = document.getElementById("aliniacion_cabecera");
  let tamanoC = document.getElementById("tamano_cabecera");
  let colorP = document.getElementById("color_parrafo");
  let fuenteP = document.getElementById("fuente_parrafo");
  let alingP = document.getElementById("aliniacion_parrafo");
  let tamanoP = document.getElementById("tamano_parrafo");
  sessionStorage.setItem("Color Fondo", color.value);
  sessionStorage.setItem("Color Cabecera", colorC.value);
  sessionStorage.setItem("Fuente Cabecera", fuenteC.value);
  sessionStorage.setItem("Alineación Cabecera", alingC.value);
  sessionStorage.setItem("Tamaño Cabecera", tamanoC.value);
  sessionStorage.setItem("Color Parrafo", colorP.value);
  sessionStorage.setItem("Fuente Parrafo", fuenteP.value);
  sessionStorage.setItem("Alineación Parrafo", alingP.value);
  sessionStorage.setItem("Tamaño Parrafo", tamanoP.value);
}

function guardarLocal() {
  let color = document.getElementById("color_fondo");
  let colorC = document.getElementById("color_cabecera");
  let fuenteC = document.getElementById("fuente_cabecera");
  let alingC = document.getElementById("aliniacion_cabecera");
  let tamanoC = document.getElementById("tamano_cabecera");
  let colorP = document.getElementById("color_parrafo");
  let fuenteP = document.getElementById("fuente_parrafo");
  let alingP = document.getElementById("aliniacion_parrafo");
  let tamanoP = document.getElementById("tamano_parrafo");
  localStorage.setItem("Color Fondo", color.value);
  localStorage.setItem("Color Cabecera", colorC.value);
  localStorage.setItem("Fuente Cabecera", fuenteC.value);
  localStorage.setItem("Alineación Cabecera", alingC.value);
  localStorage.setItem("Tamaño Cabecera", tamanoC.value);
  localStorage.setItem("Color Parrafo", colorP.value);
  localStorage.setItem("Fuente Parrafo", fuenteP.value);
  localStorage.setItem("Alineación Parrafo", alingP.value);
  localStorage.setItem("Tamaño Parrafo", tamanoP.value);
}